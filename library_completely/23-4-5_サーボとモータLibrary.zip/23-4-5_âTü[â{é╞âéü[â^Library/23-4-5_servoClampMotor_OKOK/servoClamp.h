#ifndef _SERVOCLAMP_H_
#define _SERVOCLAMP_H_
#include <Servo.h>
#include <Arduino.h>

class ServoClamp{
  public:
    void servosetup();
    void gripclose();//1a.ゆっくり閉める
    void gripclose150();//2.すぐ閉める
    void gripopen();//3.ゆっくり開く
    void gripopen40();//4.すぐ開く
    void shoulderclose();//5.ゆっくりおろす
    void shoulderclose150();//6.すぐおろす
    void shoulderopen();//7.ゆっくりあげる
    void shoulderopen130();//8.ゆっくり少しあげる
    void shoulderopen40();//9.すぐあげる
    //int Cranp=0;
    //int pos16=0;
   // int pos17=0;
    Servo myservo16;
    Servo myservo17;
  private:
    
};

#endif
