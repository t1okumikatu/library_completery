#include "servoClamp.h"
 Servo myservo16;
    Servo myservo17;
    int pos16=0;
   int pos17=0;
   //int Cranp=0;
void ServoClamp::servosetup() {
  myservo16.detach();   
  delay(100);
  myservo17.detach();   
  delay(100);
  myservo16.attach(16); 
  delay(100);
  myservo17.attach(17); 
  delay(100);
  myservo17.write(80);  //grip open   808080
  delay(1500);
  myservo16.write(50);  //90度shoulder真上40    505050
  delay(500); 
  myservo16.detach();
  delay(100);   
  myservo17.detach();
  delay(100);
 // Motor();
  delay(100);   
}
void ServoClamp::gripclose(){//1a.ゆっくり閉める
   myservo17.attach(17); 
   delay(50);
   for (pos17 = 80; pos17 <= 160; pos17 += 1) { // goes from 0 degrees to 180 degrees
   myservo17.write(pos17);// tell servo to go to position in variable 'pos'
   delay(50);
  Serial.println(pos17);  
}
//myservo17.detach();
   delay(15);
}
void ServoClamp::gripclose150(){//2.すぐ閉める
   myservo17.attach(17);
   delay(50); 
   myservo17.write(160);              // tell servo to go to position in variable 'pos'
   delay(15);
}
void ServoClamp::gripopen(){//3j.ゆっくり開く
  myservo17.attach(17); 
   delay(15);
  for (pos17 = 160; pos17 >= 50; pos17 -= 1){ // goes from 0 degrees to 180 degrees
    myservo17.write(pos17);
    delay(50); // tell servo to go to position in variable 'pos'
    Serial.println(pos17);
    delay(15);                       // waits 15ms for the servo to reach the position
  }
  myservo17.detach();
  delay(150);
}
void ServoClamp::gripopen40(){//4 i.すぐ開く
   myservo17.attach(17);
   delay(50);
   myservo17.write(50);
   delay(50);// tell servo to go to position in variable 'pos'
   myservo17.detach();  
   delay(15);
}
void ServoClamp::shoulderclose(){//5d.ゆっくりおろす
  myservo16.attach(16);
   delay(100);
for (pos16 = 50; pos16 <= 170; pos16 += 1) { // goes from 0 degrees to 180 degrees
    // in steps of 1 degree
    myservo16.write(pos16); 
    delay(50); // tell servo to go to position in variable 'pos'
     Serial.println(pos16);
    delay(15);                       // waits 15ms for the servo to reach the position
  }
   myservo16.detach();
   delay(100);
}
void ServoClamp::shoulderclose150(){//6.すぐおろす
  myservo16.attach(16);
   delay(50);
  myservo16.write(170);              // tell servo to go to position in variable 'pos'
   delay(50);
  myservo16.detach();
   delay(50);
}
void ServoClamp::shoulderopen(){//7e.ゆっくりあげる
   myservo16.attach(16); 
   delay(100);
   
   for (pos16 = 170; pos16 >= 50; pos16 -= 1) { // goes from 180 degrees to 0 degrees
    myservo16.write(pos16);
    delay(50); // tell servo to go to position in variable 'pos'
     Serial.println(pos16);
     delay(15);   
  }
  myservo16.detach();
   delay(100);
}

void ServoClamp::shoulderopen130(){//8.ゆっくり少しあげる
    myservo16.attach(16); 
    delay(50);
    for (pos16 = 170; pos16 >= 130; pos16 -= 1) { // goes from 180 degrees to 0 degrees
    myservo16.write(pos16); 
    delay(50);// tell servo to go to position in variable 'pos'
    Serial.println(pos16);
    delay(50); 
}
    myservo16.detach(); 
    delay(50);
}
void ServoClamp::shoulderopen40(){//9.すぐあげる
  myservo16.attach(16); 
    delay(50);
  myservo16.write(40);              // tell servo to go to position in variable 'pos'
    delay(50);
  myservo16.detach();  
   delay(15);
}
