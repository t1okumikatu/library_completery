#include "Arduino.h"
#include "Remote.h"
#include "WiFi.h"
#include "ArduinoOTA.h"
const char *ssid = "arduinoOTA11_11"; // 適宜設定
const char *pass = ""; // 適宜設定
const IPAddress ip(192, 168, 11,11 );      // IPアドレス
const IPAddress gateway(192, 168,11,1);
const IPAddress subnet(255, 255, 255, 0); // サブネットマスク
Remote::Remote(int pin)
{    
  pinMode(pin, OUTPUT);
  _pin = pin;
}
void Remote::setupA(){
    Serial.begin(115200);
  delay(100);

  // WiFi AP設定
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAPConfig(ip, gateway, IPAddress(255, 255, 255, 0));
  WiFi.softAP(ssid, pass);
  IPAddress myIP = WiFi.softAPIP();
  Serial.println(myIP); // IPアドレス確認
   // OTA設定
  // 以下，消さない
  ArduinoOTA
  .onStart([]() {
    String type;
    if (ArduinoOTA.getCommand() == U_FLASH)
      type = "sketch";
    else // U_SPIFFS
      type = "filesystem";
    // NOTE: if updating SPIFFS this would be the place to unmount SPIFFS using SPIFFS.end()
    Serial.println("Start updating " + type);
  })
  .onEnd([]() {
    Serial.println("\nEnd");
  })
  .onProgress([](unsigned int progress, unsigned int total) {
    Serial.printf("Progress: %u%%\r", (progress / (total / 100)));
  })
  .onError([](ota_error_t error) {
    Serial.printf("Error[%u]: ", error);
    if (error == OTA_AUTH_ERROR) Serial.println("Auth Failed");
    else if (error == OTA_BEGIN_ERROR) Serial.println("Begin Failed");
    else if (error == OTA_CONNECT_ERROR) Serial.println("Connect Failed");
    else if (error == OTA_RECEIVE_ERROR) Serial.println("Receive Failed");
    else if (error == OTA_END_ERROR) Serial.println("End Failed");
  });
  ArduinoOTA.begin();
  //ArduinoOTA.handle(); // 消さない
}
