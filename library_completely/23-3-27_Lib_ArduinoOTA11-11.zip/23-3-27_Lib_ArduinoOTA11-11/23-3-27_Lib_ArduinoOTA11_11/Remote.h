#ifndef Remote_h
#define Remote_h
#include "Arduino.h"
#include "WiFi.h"


class Remote
{
  public:
    Remote(int pin);
    void setupA();
    
  private:
    int _pin;
   
};

#endif
